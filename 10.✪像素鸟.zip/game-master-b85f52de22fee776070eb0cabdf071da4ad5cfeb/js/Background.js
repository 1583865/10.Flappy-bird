// 背景

function Background(img, step, x, y) {
	this.img = img;
	this.step = step;
	this.x = x;
	this.y = y;


}